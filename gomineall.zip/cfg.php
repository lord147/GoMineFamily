<?php

$useragent = "Mozilla/5.0 (Linux; Android 8.1.0; Redmi 6A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36";

$ctrx = "xxxx";

$cdoge = "xxxx";

$cltc = "xxxx";

$czec = "xxxx";